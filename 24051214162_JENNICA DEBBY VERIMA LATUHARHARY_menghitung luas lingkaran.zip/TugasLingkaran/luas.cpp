#include <iostream>
#include <math.h>

using namespace std;

int main() {
    const float pi = 3.14;
    float radius, luas;

    cout << "Input jari-jari Lingkaran : ";
    cin >> radius;

    luas = pi * pow(radius,2);

    cout << "Luas Lingkaran adalah : " << luas << endl;

    return 0;
}